my_list = list('ABcdEfghI')
i = 0

while i < len(my_list):
    if 'A' <= my_list[i] <= 'Z':
        print(my_list[i])
    i += 1
# gata programul
